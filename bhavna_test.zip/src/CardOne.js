import React from "react";
import { Button, ListGroup, Row, Container, Col, Card } from "react-bootstrap";
import { GiDeliveryDrone } from "react-icons/gi";
import { MdCollectionsBookmark } from "react-icons/md";
import img from './hermes.svg'
import one from './allservices.json'

export const CardOne = () => {
  return (
    <div>
     
      <ListGroup horizontal className="buttons">
        <ListGroup.Item className="list">
          <Button variant="outline-primary">
            <p>
              <GiDeliveryDrone />
            </p>
            <p>All</p>
            <p>from £2.65</p>
          </Button>
        </ListGroup.Item>
        <ListGroup.Item className="list">
          <Button variant="outline-primary">
            <p>
              <MdCollectionsBookmark />
            </p>
            <p>Collection</p>
            <p>from £2.65</p>
          </Button>
        </ListGroup.Item>
      </ListGroup>
      <Container>
        <Row>
          <Col xs={6} md={6}>
            {console.log('data', one)}

            {one.map((all, index, i)=> {
              console.log(all);        
                           
              return (              
              
            <Card style={{ width: "25rem" }} >
              <Card.Header style={{ display: "flex" }}>
                <div style={{ width: "120px", padding: "20px 10px" }}>
                  <img src="https://ph-test.parcelvision.net/content/images/select-service/hermes.svg" />
                </div>
                <div style={{ borderLeft: "1px solid #dad9d9", padding: "0 10px", width: "33%" }}>
                  <span>
                  <span>Delivery by</span>
                  <p>{all.collectionDate}</p>
                  </span>
                </div>
                <div style={{width: "33%", textAlign: "right" }}>
                  <img src="https://ph-test.parcelvision.net/content/images/select-service/icons/icon_info_grey.svg"/>
                </div>
              </Card.Header>
              <Card.Body>
               
                <Card.Text>
                  <div style={{ display: "flex", padding: "20px 10px" }}>
                  <div class="collection-time-section">
                    <span>Drop by</span>
                    <div class="view-head-right" data-isvatapplicable="Y" data-isupsnitoeu="N">
                            
                            <h3 class="text-price">
                                <span>£ <span class="ship-cost">5.87</span>
                                    
                                </span>
                            </h3>
                            
                            <h4 class="text-price-ext">£ <span class="new-price">7.04</span>
                                <span class="inc-vat">inc VAT</span>
                            </h4>
                            
                        </div>
                  </div>
                  <div><Button variant="success">BOOK NOW</Button></div>
                  </div>
                  <div style={{ display: "flex", padding: "20px 10px" }}>
                  <div class="collection-time-section">
                    <span>Drop by</span>
                    <div class="view-head-right" data-isvatapplicable="Y" data-isupsnitoeu="N">
                            
                            <h3 class="text-price">
                                <span>£ <span class="ship-cost">5.87</span>
                                    
                                </span>
                            </h3>
                            
                            <h4 class="text-price-ext">£ <span class="new-price">7.04</span>
                                <span class="inc-vat">inc VAT</span>
                            </h4>
                            
                        </div>
                  </div>
                  <div><Button variant="success">BOOK NOW</Button></div>
                  </div>
                </Card.Text>
                
              </Card.Body>
            </Card>
            )
            })}
          </Col>
          <Col xs={6} md={6}>
            <Card style={{ width: "25rem" }}>
            <Card.Header style={{ display: "flex" }}>
                <div style={{ width: "120px", padding: "20px 10px" }}>
                  <img src="https://ph-test.parcelvision.net/content/images/select-service/hermes.svg" />
                </div>
                <div style={{ borderLeft: "1px solid #dad9d9", padding: "0 10px" }}>
                  <span>
                  <span>Delivery by</span>
                  <p>Wed 22nd</p>
                  </span>
                </div>
                <div style={{width: "33%", textAlign: "right" }}>
                  <img src="https://ph-test.parcelvision.net/content/images/select-service/icons/icon_info_grey.svg"/></div>
              </Card.Header>
              <Card.Body>
               
                <Card.Text>
                  <div style={{ display: "flex", padding: "20px 10px" }}>
                  <div class="collection-time-section">
                    <span>Drop by</span>
                    <div class="view-head-right" data-isvatapplicable="Y" data-isupsnitoeu="N">
                            
                            <h3 class="text-price">
                                <span>£ <span class="ship-cost">5.87</span>
                                    
                                </span>
                            </h3>
                            
                            <h4 class="text-price-ext">£ <span class="new-price">7.04</span>
                                <span class="inc-vat">inc VAT</span>
                            </h4>
                            
                        </div>
                  </div>
                  <div><Button variant="success">BOOK NOW</Button></div>
                  </div>

                  <div style={{ display: "flex", padding: "20px 10px" }}>
                  <div class="collection-time-section">
                    <span>Drop by</span>
                    <div class="view-head-right" data-isvatapplicable="Y" data-isupsnitoeu="N">
                            
                            <h3 class="text-price">
                                <span>£ <span class="ship-cost">5.87</span>
                                    
                                </span>
                            </h3>
                            
                            <h4 class="text-price-ext">£ <span class="new-price">7.04</span>
                                <span class="inc-vat">inc VAT</span>
                            </h4>
                            
                        </div>
                  </div>
                  <div><Button variant="success">BOOK NOW</Button></div>
                  </div>

                  <div style={{ display: "flex", padding: "20px 10px" }}>
                  <div class="collection-time-section">
                    <span>Drop by</span>
                    <div class="view-head-right" data-isvatapplicable="Y" data-isupsnitoeu="N">
                            
                            <h3 class="text-price">
                                <span>£ <span class="ship-cost">5.87</span>
                                    
                                </span>
                            </h3>
                            
                            <h4 class="text-price-ext">£ <span class="new-price">7.04</span>
                                <span class="inc-vat">inc VAT</span>
                            </h4>
                            
                        </div>
                  </div>
                  <div><Button variant="success">BOOK NOW</Button></div>
                  </div>
                </Card.Text>
               
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
};
